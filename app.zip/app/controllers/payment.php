<?php

class Payment extends Controller {



   public function index(){

    //$User = $this->load_model('User');

    //od paypal-a dobijamo inf putem json-a
    $data = file_get_contents('php://input');

    //vrijeme
    $filename = time() . "_.txt";

    //spremanje podataka
    file_put_contents($filename, $data);

    }



}




?>

