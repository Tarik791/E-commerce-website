<?php $this->view("header", $data); ?>

<?php $this->view("slider", $data); ?>


<section>
<div class="container">
    <div class="row">

    <center><h1>Thanks for shopping with us!</h1></center>
    </div>
</div>
</section>

<?php

$this->view("footer", $data);

?>
